import requests

url = "https://dummyjson.com/auth/login"

credentials = {
    "username": "kminchelle",
    "password": "0lelplR"
}

headers = {
    "Content-Type": "application/json"
}

try:
    response = requests.post(url, json=credentials, headers=headers)
    data = response.json()

    if response.status_code == 200:
        print("Login successful")
        print(data)
    else:
        print("Login failed:", data.get("message"))

except requests.exceptions.RequestException as e:
    print("Network error:", e)
